#include <graphics.h>
#include <math.h>
#include <stdio.h>

int height,width; 
int score=0; 
float g,ball_x,ball_y,ball_vy,ball_r; 
float rect_x,rect_y,rect_w,rect_h,rect_vx;	 
float rect1_x,rect1_y,rect1_w,rect1_h,rect1_vx;	

void start()
{setcolor(EGEACOLOR(0,BLUE));
setbkmode(TRANSPARENT);	
PIMAGE bkimg=newimage();	
getimage(bkimg,"./picture/bk.bmp");
PIMAGE s=newimage();	
putimage(0,0,bkimg);
getimage(s,"./picture/start.bmp");
putimage_transparent(NULL,s,100,100,BLACK);
setfont(-40,0,"黑体");
xyprintf(140,260,"任意键开始游戏哦");
}



void endgame()
{PIMAGE go=newimage();	
getimage(go,"./picture/end.bmp");
putimage_transparent(NULL,go,100,100,BLACK);
setfont(-40,0,"黑体");
xyprintf(80,200,"游戏结束！");	
xyprintf(80,260,"您的得分为：");
xyprintf(80,320,"%d分",score);
xyprintf(120,400,"按任意键重开哦");
} 

void game()
{
height=600;
width=540;	
	
ball_r=25;	
ball_x=width/4;
ball_y=height-ball_r;
g=0.7;
	
rect_h=200;
rect_w=65;
rect_y=height-rect_h;
rect_x=width; 
rect_vx=-5;
	
rect1_h=100;
rect1_w=65;
rect1_x=380;
rect1_y=0; 
rect1_vx=-5;
	
	
initgraph(  width,height );
start();
getch();
setbkcolor(EGERGB(192,192,192));
setcolor( EGERGB(0xff, 0xff, 0xff) );
setfillcolor( EGERGB(0, 0, 0xff) );
setrendermode(RENDER_MANUAL);
ege_enable_aa(true); 	 
    

PIMAGE bkimg=newimage();	
getimage(bkimg,"./picture/bk.bmp"); 

PIMAGE r=newimage();	
getimage(r,"./picture/up.bmp"); 
PIMAGE r1=newimage();	
getimage(r1,"./picture/down.bmp");
	
PIMAGE bird[4];
bird[0]=newimage();
getimage(bird[0],"./picture/bird0.bmp");
bird[1]=newimage();
getimage(bird[1],"./picture/bird1.bmp");
bird[2]=newimage();
getimage(bird[2],"./picture/bird2.bmp");
bird[3]=newimage();
getimage(bird[3],"./picture/bird1.bmp");
    


int count=0;
for ( ; is_run();delay_fps(60) ,count++ )	
{
count%=60;
    	
if(kbhit())	 
{char input=getch();	 
if(input==' ')
ball_vy=-10;
}
		

ball_vy+=g;
ball_y+=ball_vy;
 
if(ball_y>=height-ball_r)
{ball_vy=0;
ball_y=height-ball_r;} 
		
		
rect1_x+=rect1_vx;

if(rect1_x<=-rect1_w)
{rect1_x=width;
rect1_h=random(400);
}	
		
rect_x+=rect_vx;

if(rect_x<=-rect_w)
{rect_x=width;
rect_y=rect1_h+150;	
rect_h=height-rect_y; 
}
		 
	
if(rect_x==85)
score++;
		
 
if((rect_x<ball_x+ball_r)&&(rect_x+rect_w>ball_x-ball_r)&&(rect_y<ball_y+ball_r))
break; 

if((rect1_x<ball_x+ball_r)&&(rect1_x+rect1_w>ball_x-ball_r)&&(rect1_h>ball_y))
break;
		
cleardevice(); 
		
putimage(0,0,bkimg);	

switch(count/15)
{case 0:
	putimage_transparent(NULL,bird[0],ball_x-ball_r,ball_y-ball_r,BLACK);break;
case 1:
	putimage_transparent(NULL,bird[1],ball_x-ball_r,ball_y-ball_r,BLACK);break;
case 2:
	putimage_transparent(NULL,bird[2],ball_x-ball_r,ball_y-ball_r,BLACK);break;
case 3:
	putimage_transparent(NULL,bird[3],ball_x-ball_r,ball_y-ball_r,BLACK);break;
}
		
putimage_transparent(NULL,r1,rect1_x,rect1_y,BLACK,0,400-rect1_h,65,rect1_h);
putimage_transparent(NULL,r,rect_x,rect_y,BLACK);
        

setfont(-20,0,"宋体");
setcolor(EGEACOLOR(0,BLUE));
setbkmode(TRANSPARENT);	
xyprintf(30,30,"您的分数为%d分",score);
}}

void gg()
{game();
endgame();}

int main()
{while(1)
{gg();
getch();
score=0;}
return 0;}
    
